<html><body><?php
$number=0;
 $number = count($_POST["name"]);
 $total_amount = $_POST["TAmount"];
 $average=0;
 if($total_amount>0){
 $average = $total_amount/$number;
}
 if($number > 0 && $total_amount > 0 && isset($_POST["name"]) && isset($_POST["share"]))
 {
   echo "<br>";
   echo "Total Amount = ".$total_amount."<br>";
  if (array_sum($_POST["share"])==$total_amount) {
    echo '<table class="table table-bordered" id="results_split">
     <tr>
         <td>'."NAME".'</td>
         <td>'."SHARE".'</td>
         <td>'."DIFFERENCE".'</td>
         <td>'."EMAIL ID".'</td>
     </tr>';

    $differ = array();
    $dict = array(); //2d array
     for($i=0; $i<$number; $i++){
          $differ[$i] = $_POST["share"][$i] - $average;
          $name_dict=$_POST["name"][$i];
          $dict[$name_dict] = $differ[$i];
    echo '
     <tr>
         <td>'.$_POST["name"][$i].'</td>
         <td>'.$_POST["share"][$i].'</td>
         <td>'.$differ[$i].'</td>
         <td>'.$_POST["email"][$i].'</td>
     </tr>';

  }
  echo '
  </table>';
  }
  else{
    if(array_sum($_POST["share"])>$total_amount){
      $ex_am = array_sum($_POST["share"])-$total_amount;
      echo "YOUR SHARES EXCEED TOTAL AMOUNT : ".$total_amount." BY ".$ex_am;
    }
    else{
      if(array_sum($_POST["share"])<$total_amount){
        $short_am = $total_amount-array_sum($_POST["share"]);
        echo "YOU NEED ".$short_am." MORE TO PAY TOTAL AMOUNT : ".$total_amount;
      }
    }
    echo "<br>PLEASE ENTER CORRECT SHARES";
  }
asort($dict);
$allKeys = array_keys($dict);
for($i=0;$i<$number;$i++){
  asort($dict);
  $allKeys = array_keys($dict);
  $diff_i=$number-1;

  if(array_values($dict)[$diff_i] > 0 && array_values($dict)[0] < 0){
    if(-array_values($dict)[0] > array_values($dict)[$diff_i]){
      echo " ".$allKeys[0]." WILL PAY ".$allKeys[$diff_i]." : ".array_values($dict)[$diff_i]."<br>";
      $dict[$allKeys[0]]=array_values($dict)[$diff_i]-abs(array_values($dict)[0]);
      $dict[$allKeys[$diff_i]]=0;
    }
    elseif (abs(array_values($dict)[$i]) < array_values($dict)[$diff_i]) {
      echo " ".$allKeys[0]." WILL PAY ".$allKeys[$diff_i]." : ".abs(array_values($dict)[0])."<br>";
      $dict[$allKeys[$diff_i]]=array_values($dict)[$diff_i]+array_values($dict)[0];
      $dict[$allKeys[0]]=0;
    }

  }

}
}

 ?>
</body>
</html>
