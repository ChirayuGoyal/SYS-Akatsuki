<html>
      <head>
           <title>SYS Akatsuki</title>
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
           <script type="text/javascript" src="jquery-1.3.2.js" ></script>
           <script type="text/javascript" src="html2CSV.js" ></script>
           <style>
img {text-align: center;}
body {background-color: #F7826F;}
div {text-align: center;}
h1 {color : #902020;}
</style>
      </head>
      <body>
           <div class="container">
             <font align="center"><img src="Code_stock-removebg-preview.png" width="300" height=auto></font>
                <br />
                <br />
                <h1 color="#902020">SYS Akatsuki PRESENTS</h1>
                <h1 color="#902020"><b>ControBILL</b></h1>
                <h2 align="center">Split Payment among your Friends!!</h2><br><br>
                <div class="form-group">
                     <form name="add_name" id="add_name"  >
                       Enter Amount : <input type="number" name= "TAmount" placeholder="Enter your Amount">
                       <br><br>
                          <div class="table-responsive">
                               <table class="table table-bordered" id="dynamic_field">
                                    <tr>
                                         <td><input type="text" name="name[]" placeholder="Enter your Name" class="form-control name_list" /></td>
                                         <td><input type="number" name="share[]" placeholder="Enter your Share" class="form-control name_list" /></td>
                                         <td><input type="email" name="email[]" placeholder="Enter your Email ID" class="form-control name_list" /></td>
                                         <td><button type="button" name="add" id="add" class="btn btn-success">Add More</button></td>
                                    </tr>
                               </table>
                               <input type="button" name="submit" id="submit" class="btn btn-info" value="Submit" />

                               <input value="Export as CSV" class="btn btn-info" type="button" onclick="$('#results_split').table2CSV()">
                          </div>
                     </form>
                </div>
                <div class="output" align="center" style="font-size:30px">

                </div>
           </div>
      </body>
 </html>
 <script>
 $(document).ready(function(){
      var i=1;
      $('#add').click(function(){
           i++;
           $('#dynamic_field').append('<tr id="row'+i+'"><td><input type="text" name="name[]" placeholder="Enter your Name" class="form-control name_list" /></td><td><input type="number" name="share[]" placeholder="Enter your Share" class="form-control name_list" /></td><td><input type="email" name="email[]" placeholder="Enter your Email ID" class="form-control name_list" /></td></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');

      });
      $(document).on('click', '.btn_remove', function(){
           var button_id = $(this).attr("id");
           $('#row'+button_id+'').remove();
      });
      $('#submit').click(function(){
           $.ajax({
                url:"back.php",
                method:"POST",
                data:$('#add_name').serialize(),
                success:function(data)
                {
                  $("div.output").empty();
                     $("div.output").append(data);
                    // $('#add_name')[0].reset();
                }
           });
      });
//EXPORT RESULTS
      $('#d1').click(function(){
        $.ajax({
          data:$('#add_name').serialize(),
          success:function(data)
          {
            //$("div.output").empty();
              // $("div.output").append(data);
              // $('#add_name')[0].reset();
              $data.table2csv({
                seperator: ',',
                newline: '\n',
                quoteFields:true,
                filename: 'table.csv'
              });
          }
        });
      });
 });
 </script>
